"""
Tool untuk fitur pilihan (Tahap 5). Tool yang ditulis di sini otomatis terdaftar
dan langsung bisa dipakai asisten di terminal maupun di layar ERP.

Pola lengkapnya ada di asisten/tools.py (lihat cari_produk). Daftar view dan kolomnya
ada di bagian atas file itu.
"""
from __future__ import annotations

from . import db
from . import format as fmt
from .tools import _cocokkan, tool  # noqa: F401


@tool(
    nama="stok_di_bawah_minimum",
    deskripsi=("Daftar produk yang stoknya di bawah stok minimum per gudang, diurutkan dari kekurangan terbesar. "
               "Gunakan untuk pertanyaan stok menipis atau barang yang perlu segera diproduksi/dipesan."),
    parameter={
        "type": "object",
        "properties": {"jumlah": {"type": "integer", "description": "Jumlah baris (1-20). Default 5."}},
        "required": [],
    },
    izin="stok",
)
def stok_di_bawah_minimum(jumlah: int = 5) -> dict:
    baris = db.query(
        """
        SELECT produk, gudang, qty, stok_minimum, stok_minimum - qty AS kekurangan
        FROM ai.v_stok WHERE di_bawah_minimum ORDER BY kekurangan DESC
        LIMIT %(n)s
        """, {"n": max(1, min(int(jumlah or 5), 20))})
    total = db.query("SELECT count(*) AS n FROM ai.v_stok WHERE di_bawah_minimum")[0]["n"]
    return {"jumlah_di_bawah_minimum": total, "data": baris,
            "catatan": "" if baris else "Tidak ada stok di bawah minimum."}


@tool(
    nama="piutang_terbesar",
    deskripsi=("Daftar customer dengan sisa PIUTANG (tagihan yang belum dibayar) terbesar per tanggal posisi data, "
               "beserta jumlah faktur dan berapa hari paling lama lewat jatuh tempo. Gunakan untuk pertanyaan tentang "
               "piutang, tagihan, penagihan, atau customer yang telat bayar / lewat jatuh tempo."),
    parameter={
        "type": "object",
        "properties": {
            "jumlah": {"type": "integer", "description": "Jumlah customer (1-20). Default 5."},
            "min_hari_lewat_jatuh_tempo": {
                "type": "integer",
                "description": "Hanya hitung faktur yang sudah lewat jatuh tempo minimal sekian hari, mis. 60. Default 0 (semua piutang)."},
        },
        "required": [],
    },
    izin="piutang",
)
def piutang_terbesar(jumlah: int = 5, min_hari_lewat_jatuh_tempo: int = 0) -> dict:
    jumlah = max(1, min(int(jumlah or 5), 20))
    min_hari = max(0, int(min_hari_lewat_jatuh_tempo or 0))
    baris = db.query(
        """
        SELECT customer, kota, segmen,
               count(*)                    AS jumlah_faktur,
               sum(sisa)                   AS sisa_piutang,
               max(hari_lewat_jatuh_tempo) AS hari_terlama_lewat_jatuh_tempo
        FROM ai.v_piutang
        WHERE hari_lewat_jatuh_tempo >= %(min_hari)s
        GROUP BY customer, kota, segmen
        ORDER BY sisa_piutang DESC
        LIMIT %(n)s
        """,
        {"min_hari": min_hari, "n": jumlah},
    )
    for b in baris:
        b["sisa_piutang_fmt"] = fmt.rupiah(b["sisa_piutang"])
    posisi = db.info()["tanggal_posisi"]
    return {
        "posisi_per": f"{posisi:%d-%m-%Y}",
        "filter": f"faktur lewat jatuh tempo ≥ {min_hari} hari" if min_hari else "semua faktur belum lunas",
        "data": baris,
        "catatan": "Tidak ada customer yang memenuhi kriteria." if not baris else "",
        "grafik": {
            "tipe": "bar",
            "judul": "Customer dengan piutang terbesar (Rp juta)",
            "label": [b["customer"] for b in baris],
            "seri": [{"nama": "Sisa piutang (Rp juta)", "data": [round(b["sisa_piutang"] / 1e6, 1) for b in baris]}],
            "horizontal": True,
        },
    }


@tool(
    nama="margin_produk",
    deskripsi=("Margin kotor per produk bulan terakhir (harga jual dibanding HPP per unit), dari yang paling tipis. "
               "Gunakan untuk pertanyaan produk yang marginnya rendah atau paling tertekan."),
    parameter={
        "type": "object",
        "properties": {"jumlah": {"type": "integer", "description": "Jumlah produk (1-20). Default 5."}},
        "required": [],
    },
    izin="hpp",
)
def margin_produk(jumlah: int = 5) -> dict:
    baris = db.query(
        """
        SELECT h.produk, p.harga_jual, h.hpp_per_unit,
               round((p.harga_jual - h.hpp_per_unit) / p.harga_jual * 100, 1) AS margin_persen
        FROM ai.v_hpp_bulanan h
        JOIN ai.v_produk p ON p.id = h.produk_id
        WHERE h.bulan = (SELECT date_trunc('month', tanggal_posisi)::date FROM ai.v_info)
        ORDER BY margin_persen ASC
        LIMIT %(n)s
        """, {"n": max(1, min(int(jumlah or 5), 20))})
    for b in baris:
        b["harga_jual_fmt"] = fmt.rupiah(b["harga_jual"])
        b["hpp_per_unit_fmt"] = fmt.rupiah(b["hpp_per_unit"])
        b["margin_fmt"] = fmt.persen(b["margin_persen"], tanda=False)
    return {"bulan": fmt.bulan(db.info()["bulan_terakhir"]), "data": baris}


@tool(
    nama="piutang_customer",
    deskripsi=("Rincian faktur yang belum lunas milik SATU customer: nomor faktur, tanggal, jatuh tempo, sisa tagihan, "
               "dan jumlah hari lewat jatuh tempo. Gunakan untuk menyusun surat penagihan atau menjawab "
               "pertanyaan tagihan customer tertentu."),
    parameter={
        "type": "object",
        "properties": {"customer": {"type": "string", "description": "Nama customer, mis. 'CV Laju Makmur Abadi'."}},
        "required": ["customer"],
    },
    izin="piutang",
)
def piutang_customer(customer: str) -> dict:
    semua = db.query("SELECT id, kode, nama, kota, segmen, termin_hari FROM ai.v_customer ORDER BY nama")
    rendah = " ".join(str(customer).lower().split())
    cocok = [c for c in semua if rendah in (c["nama"].lower(), c["kode"].lower())] or _cocokkan(customer, semua, {})
    if len(cocok) != 1:
        return {"error": f"Customer '{customer}' tidak ditemukan atau ambigu. Tanyakan ke user customer yang dimaksud.",
                "kandidat": [c["nama"] for c in cocok[:10]]}
    c = cocok[0]
    faktur = db.query(
        """
        SELECT nomor_faktur, tanggal, jatuh_tempo, total, terbayar, sisa, hari_lewat_jatuh_tempo
        FROM ai.v_piutang WHERE customer_id = %(id)s
        ORDER BY jatuh_tempo
        """, {"id": c["id"]})
    for f in faktur:
        f["sisa_fmt"] = fmt.rupiah(f["sisa"])
    posisi = db.info()["tanggal_posisi"]
    return {
        "customer": c["nama"], "kota": c["kota"], "segmen": c["segmen"], "termin_hari": c["termin_hari"],
        "posisi_per": f"{posisi:%d-%m-%Y}",
        "jumlah_faktur": len(faktur),
        "total_sisa_fmt": fmt.rupiah(sum(f["sisa"] for f in faktur)),
        "hari_terlama_lewat_jatuh_tempo": max((f["hari_lewat_jatuh_tempo"] for f in faktur), default=0),
        "data": faktur,
        "catatan": "" if faktur else "Customer ini tidak punya faktur yang belum lunas.",
    }

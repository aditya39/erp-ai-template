"""
Jejak audit asisten: setiap pertanyaan dicatat satu baris JSON di log/aktivitas.jsonl.

Yang dicatat: waktu, user, pertanyaan, model, tool yang dipakai beserta statusnya (ok / ditolak / error).
Jawaban model tidak disimpan: isinya bisa memuat data yang hak aksesnya berbeda dengan pembaca log.
Di aplikasi sungguhan, catatan ini masuk ke tabel audit ERP, bukan ke file.
"""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

from . import config

FILE_LOG: Path = config.FOLDER_LOG / "aktivitas.jsonl"


def catat(pengguna: str, pertanyaan: str, mode: str, model: str, tools: list[dict], durasi_ms: int) -> None:
    """Tambahkan satu baris ke log. Kegagalan menulis log tidak boleh menggagalkan jawaban."""
    baris = {
        "waktu": dt.datetime.now().isoformat(timespec="seconds"),
        "pengguna": pengguna,
        "pertanyaan": pertanyaan[:500],
        "mode": mode,
        "model": model,
        "tools": [{"nama": t["nama"], "status": t["status"]} for t in tools],
        "durasi_ms": durasi_ms,
    }
    try:
        FILE_LOG.parent.mkdir(parents=True, exist_ok=True)
        with FILE_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(baris, ensure_ascii=False) + "\n")
    except OSError:
        pass


def baca(jumlah: int = 50) -> list[dict]:
    """Catatan terbaru lebih dulu."""
    if not FILE_LOG.exists():
        return []
    hasil = []
    for baris in FILE_LOG.read_text(encoding="utf-8").splitlines():
        try:
            hasil.append(json.loads(baris))
        except ValueError:
            continue
    return hasil[::-1][:max(1, int(jumlah))]

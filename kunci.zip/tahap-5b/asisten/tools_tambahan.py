"""
Tool untuk fitur pilihan (Tahap 5). Tool yang ditulis di sini otomatis terdaftar
dan langsung bisa dipakai asisten di terminal maupun di layar ERP.

Pola lengkapnya ada di asisten/tools.py (lihat cari_produk). Daftar view dan kolomnya
ada di bagian atas file itu.
"""
from __future__ import annotations

from . import db
from . import format as fmt
from .tools import _cocokkan, tool  # noqa: F401


@tool(
    nama="piutang_customer",
    deskripsi=("Rincian faktur yang belum lunas milik SATU customer: nomor faktur, tanggal, jatuh tempo, sisa tagihan, "
               "dan jumlah hari lewat jatuh tempo. Gunakan untuk menyusun surat penagihan atau menjawab "
               "pertanyaan tagihan customer tertentu."),
    parameter={
        "type": "object",
        "properties": {"customer": {"type": "string", "description": "Nama customer, mis. 'CV Laju Makmur Abadi'."}},
        "required": ["customer"],
    },
    izin="piutang",
)
def piutang_customer(customer: str) -> dict:
    semua = db.query("SELECT id, kode, nama, kota, segmen, termin_hari FROM ai.v_customer ORDER BY nama")
    rendah = " ".join(str(customer).lower().split())
    cocok = [c for c in semua if rendah in (c["nama"].lower(), c["kode"].lower())] or _cocokkan(customer, semua, {})
    if len(cocok) != 1:
        return {"error": f"Customer '{customer}' tidak ditemukan atau ambigu. Tanyakan ke user customer yang dimaksud.",
                "kandidat": [c["nama"] for c in cocok[:10]]}
    c = cocok[0]
    faktur = db.query(
        """
        SELECT nomor_faktur, tanggal, jatuh_tempo, total, terbayar, sisa, hari_lewat_jatuh_tempo
        FROM ai.v_piutang WHERE customer_id = %(id)s
        ORDER BY jatuh_tempo
        """, {"id": c["id"]})
    for f in faktur:
        f["sisa_fmt"] = fmt.rupiah(f["sisa"])
    posisi = db.info()["tanggal_posisi"]
    return {
        "customer": c["nama"], "kota": c["kota"], "segmen": c["segmen"], "termin_hari": c["termin_hari"],
        "posisi_per": f"{posisi:%d-%m-%Y}",
        "jumlah_faktur": len(faktur),
        "total_sisa_fmt": fmt.rupiah(sum(f["sisa"] for f in faktur)),
        "hari_terlama_lewat_jatuh_tempo": max((f["hari_lewat_jatuh_tempo"] for f in faktur), default=0),
        "data": faktur,
        "catatan": "" if faktur else "Customer ini tidak punya faktur yang belum lunas.",
    }
